package com.example.mycontacts.activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.mycontacts.R;
import com.example.mycontacts.fragment.ContactListFragment;
import com.example.mycontacts.fragment.LoginFragment;
import com.example.mycontacts.receiver.MyReceiver;
import com.example.mycontacts.utils.Constants;
import com.example.mycontacts.utils.SharedPreferenceHelper;

public class MainActivity extends AppCompatActivity {
    private MyReceiver receiver;
    private IntentFilter broadcastFilter;
    private IntentFilter localBroadcastFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initBroadcastReceiver();
        loadFragment();
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();

        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void onResume(){
        super.onResume();
        registerReceiver(receiver, broadcastFilter);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, localBroadcastFilter);
        //sendMyBroadcast();
        sendLocalBroadcast();
    }

    @Override
    public void onPause(){
        super.onPause();
        unregisterReceiver(receiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

    private void initBroadcastReceiver(){
        receiver = new MyReceiver();

        broadcastFilter = new IntentFilter();
        broadcastFilter.addAction(Constants.KEY_BROADCAST);

        localBroadcastFilter = new IntentFilter();
        localBroadcastFilter.addAction(Constants.KEY_LOCAL_BROADCAST);
    }

    private void loadFragment(){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if(new SharedPreferenceHelper().isLoggedIn(this)){
            ContactListFragment contactListFragment = new ContactListFragment();
            fragmentTransaction.add(R.id.main_fl_container, contactListFragment, contactListFragment.getTag());
        }
        else{
            LoginFragment loginFragment = new LoginFragment();
            fragmentTransaction.add(R.id.main_fl_container, loginFragment, loginFragment.getTag());
        }

        fragmentTransaction.commit();
    }

    /*
    * For broadcast
    * */
    private void sendMyBroadcast(){
        Intent intent = new Intent();
        intent.setAction(Constants.KEY_BROADCAST);
        sendBroadcast(intent);
    }

    /*
    * For local broadcast
    * */
    private void sendLocalBroadcast(){
        Intent intent = new Intent();
        intent.setAction(Constants.KEY_LOCAL_BROADCAST);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
}
