package com.example.mycontacts.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.mycontacts.R;
import com.example.mycontacts.database.DatabaseHelper;
import com.example.mycontacts.pojo.ContactsPojo;

import java.util.List;

public class AddContactFragment extends Fragment implements View.OnClickListener {
    private EditText etFName;
    private EditText etLName;
    private EditText etNumber;
    private Button btnSave;
    private Button btnGet;
    private Button btnDelete;
    private Button btnUpdate;

    private DatabaseHelper dbHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_main, null);

        initViews(view);
        initDatabase();
        initListeners();

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.main_btn_save:
                long contactId = dbHelper.addContact(getValues());

                if(contactId != 0L){
                    Toast.makeText(getActivity(), "Contact created with id: " + contactId, Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.main_btn_update:
                int numOfRows = dbHelper.updateContact(getValues());
                if(numOfRows > 0){
                    Toast.makeText(getActivity(), "No. of rows impacted: " + numOfRows, Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.main_btn_delete:
                dbHelper.deleteContact(getValues());
                break;

            case R.id.main_btn_get:
                List<ContactsPojo> contactList = dbHelper.getContacts();

                for(int i=0; i<contactList.size(); i++){
                    ContactsPojo contactsPojo = contactList.get(i);

                    int id = contactsPojo.getId();
                    String fName = contactsPojo.getFirstName();
                    String lName = contactsPojo.getLastName();
                    String number = contactsPojo.getContactNumber();

                    Log.d("Record " + i, id + "-" + fName + "-" + lName + "-" + number);
                }
                break;
        }
    }

    private void initViews(View view){
        etFName = view.findViewById(R.id.main_et_fname);
        etLName = view.findViewById(R.id.main_et_lname);
        etNumber = view.findViewById(R.id.main_et_number);
        btnSave = view.findViewById(R.id.main_btn_save);
        btnUpdate = view.findViewById(R.id.main_btn_update);
        btnGet = view.findViewById(R.id.main_btn_get);
        btnDelete = view.findViewById(R.id.main_btn_delete);
    }

    private void initDatabase(){
        dbHelper = new DatabaseHelper(getActivity());
    }

    private void initListeners(){
        btnSave.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnGet.setOnClickListener(this);
    }

    private ContactsPojo getValues(){
        ContactsPojo contactsPojo = new ContactsPojo();

        contactsPojo.setFirstName(etFName.getText().toString().trim());
        contactsPojo.setLastName(etLName.getText().toString().trim());
        contactsPojo.setContactNumber(etNumber.getText().toString().trim());

        return contactsPojo;
    }
}
