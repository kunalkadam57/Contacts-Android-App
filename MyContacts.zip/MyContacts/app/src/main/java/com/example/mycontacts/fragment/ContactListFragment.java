package com.example.mycontacts.fragment;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mycontacts.R;
import com.example.mycontacts.adapter.ContactsAdapter;
import com.example.mycontacts.database.DatabaseHelper;
import com.example.mycontacts.pojo.ContactsPojo;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;
import java.util.List;

public class ContactListFragment extends Fragment implements TimePickerDialog.OnTimeSetListener, View.OnClickListener {
    private RecyclerView rvContacts;
    private FloatingActionButton fabAdd;

    private DatabaseHelper dbHelper;
    private ContactsAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_contact_list, null);

        initViews(view);
        initListener();
        initDb();
        populateData();

        return view;
    }

    private void initViews(View view){
       rvContacts = view.findViewById(R.id.contact_list_rv_contacts);
       fabAdd = view.findViewById(R.id.contact_list_fab_add);
    }

    private void initListener(){
        fabAdd.setOnClickListener(this);
    }

    private void initDb(){
        dbHelper = new DatabaseHelper(getActivity());
    }

    private void populateData(){
        List<ContactsPojo> listContacts = dbHelper.getContacts();

        if(listContacts.isEmpty()){
            displayAlert();
//            displayTimePickerDialog();
        }
        else{
            adapter = new ContactsAdapter(listContacts);
            rvContacts.setLayoutManager(new LinearLayoutManager(getActivity()));
            rvContacts.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
    }

    private void displayAlert(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("Alert!");
        builder.setMessage("No records founds...");
        builder.setPositiveButton("OK", null);
        builder.setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void displayTimePickerDialog(){
        Calendar calendar = Calendar.getInstance();

        TimePickerDialog dialog = new TimePickerDialog(getActivity(), this, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false);
        dialog.show();
    }

    @Override
    public void onTimeSet(TimePicker timePicker, int i, int i1) {
        Toast.makeText(getActivity(), "Time is: " + i + ":" + i1, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.contact_list_fab_add){
            AddContactFragment addContactFragment = new AddContactFragment();

            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
            fragmentTransaction.replace(R.id.main_fl_container, addContactFragment, addContactFragment.getTag());
            fragmentTransaction.commit();
        }
    }
}
