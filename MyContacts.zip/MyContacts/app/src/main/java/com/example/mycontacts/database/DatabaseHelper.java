package com.example.mycontacts.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.mycontacts.pojo.ContactsPojo;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "MyContacts";
    private static final int DATABASE_VERSION = 1;
    private static final String KEY_TABLE_NAME = "Contacts";
    private static final String KEY_CONTACT_ID = "_id";
    private static final String KEY_CONTACT_FNAME = "fname";
    private static final String KEY_CONTACT_LNAME = "lname";
    private static final String KEY_CONTACT_NUMBER = "number";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //Create your tables here
        String CREATE_TABLE_CONTACTS = "CREATE TABLE "
                + KEY_TABLE_NAME + " ("
                + KEY_CONTACT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_CONTACT_FNAME + " VARCHAR(200), "
                + KEY_CONTACT_LNAME + " VARCHAR(200), "
                + KEY_CONTACT_NUMBER + " VARCHAR(200))";
        sqLiteDatabase.execSQL(CREATE_TABLE_CONTACTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //Alter/Drop/Delete table as per the requirement
    }

    public long addContact(ContactsPojo contactsPojo){
        long contactId;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_CONTACT_FNAME, contactsPojo.getFirstName());
        contentValues.put(KEY_CONTACT_LNAME, contactsPojo.getLastName());
        contentValues.put(KEY_CONTACT_NUMBER, contactsPojo.getContactNumber());

        contactId = db.insert(KEY_TABLE_NAME, null, contentValues);
        db.close();

        return contactId;
    }

    public int updateContact(ContactsPojo contactsPojo){
        int numOfRows;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_CONTACT_FNAME, contactsPojo.getFirstName());
        contentValues.put(KEY_CONTACT_LNAME, contactsPojo.getLastName());
        contentValues.put(KEY_CONTACT_NUMBER, contactsPojo.getContactNumber());

        numOfRows = db.update(KEY_TABLE_NAME, contentValues, KEY_CONTACT_NUMBER + " = ?", new String[]{contactsPojo.getContactNumber()});
        db.close();

        return numOfRows;
    }

    public void deleteContact(ContactsPojo contactsPojo){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(KEY_TABLE_NAME, KEY_CONTACT_NUMBER + " = ?", new String[]{contactsPojo.getContactNumber()});
        db.close();
    }

    public List<ContactsPojo> getContacts(){
        List<ContactsPojo> contactsList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(KEY_TABLE_NAME, null, null, null, null, null, null);

        if(cursor!= null && cursor.moveToFirst()){
            do{
                ContactsPojo contactsPojo = new ContactsPojo();

                contactsPojo.setId(cursor.getInt(cursor.getColumnIndex(KEY_CONTACT_ID)));
                contactsPojo.setFirstName(cursor.getString(cursor.getColumnIndex(KEY_CONTACT_FNAME)));
                contactsPojo.setLastName(cursor.getString(cursor.getColumnIndex(KEY_CONTACT_LNAME)));
                contactsPojo.setContactNumber(cursor.getString(cursor.getColumnIndex(KEY_CONTACT_NUMBER)));

                contactsList.add(contactsPojo);
            }while (cursor.moveToNext());
        }

        return contactsList;
    }
}
