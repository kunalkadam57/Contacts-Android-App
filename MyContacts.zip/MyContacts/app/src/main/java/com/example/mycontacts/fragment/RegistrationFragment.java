package com.example.mycontacts.fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.mycontacts.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class RegistrationFragment extends Fragment implements View.OnClickListener, DatePickerDialog.OnDateSetListener {
    private TextView tvDob;
    private Spinner spCountry;
    private TextView tvTerms;

    private Calendar calendar;
    private List<String> listCountries;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_registration, null);

        initViews(view);
        initData();
        initListeners();

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.fragment_reg_tv_dob_value:
                showDatePickerDialog();
                break;

            case R.id.fragment_reg_tv_terms:
                TermsFragment termsFragment = new TermsFragment();

                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_fl_container, termsFragment, termsFragment.getTag());
                fragmentTransaction.commit();
                break;
        }
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        calendar.set(i, i1, i2);

        String date;
        String month;

        if(i2 < 10){
            date = "0" + i2;
        }
        else{
            date = String.valueOf(i2);
        }

        if(i1 < 9){
            month = "0" + (i1 + 1);
        }
        else{
            month = String.valueOf(i1 + 1);
        }

        tvDob.setText(date + "-" + month + "-" + i);
    }

    private void initViews(View view){
        tvDob = view.findViewById(R.id.fragment_reg_tv_dob_value);
        tvTerms = view.findViewById(R.id.fragment_reg_tv_terms);
        spCountry = view.findViewById(R.id.fragment_reg_sp_country);
    }

    private void initData(){
        calendar = Calendar.getInstance();
        listCountries = new ArrayList<>();

        listCountries.add("India");
        listCountries.add("Pakistan");
        listCountries.add("Sri Lanka");
        listCountries.add("China");
        listCountries.add("Bangladesh");

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, listCountries);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spCountry.setAdapter(spinnerAdapter);
    }

    private void initListeners(){
        tvDob.setOnClickListener(this);
        tvTerms.setOnClickListener(this);
    }

    private void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());
        datePickerDialog.show();
    }
}
